package rekab.app.background_locator_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()